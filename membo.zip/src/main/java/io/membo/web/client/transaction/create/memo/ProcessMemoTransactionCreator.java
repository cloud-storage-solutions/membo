package io.membo.web.client.transaction.create.memo;

import io.membo.web.client.transaction.create.TransactionCreationException;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.stream.Collectors;

@Component
public class ProcessMemoTransactionCreator implements MemoTransactionCreator {
    @Override
    public String createTransaction(String memoContent) throws TransactionCreationException {
        String publicKey = "";
        String privateKey = "";
        Process exec = createPythonProcess(memoContent, publicKey, privateKey);
        String errorOutput = new BufferedReader(new InputStreamReader(exec.getErrorStream()))
                .lines().collect(Collectors.joining("\n"));
        System.out.println("Error output: " + errorOutput);
        return new BufferedReader(new InputStreamReader(exec.getInputStream()))
                .lines().collect(Collectors.joining("\n"));
    }

    private Process createPythonProcess(String memoContent, String publicKey, String privateKey) throws TransactionCreationException {
        String pythonPath = "<path-to-your-python-executable>";
        String bchmemo = "<path-to-the-bchmemo-library>"; // it's included with the project, as there are some changes to it
        try {
            return Runtime.getRuntime().exec(pythonPath + " -c \"" +
                    "import sys;" +
                    "sys.path.insert(0, '" + bchmemo + "');" +
                    "from bchmemo import MemoUser;" +
                    "user=MemoUser('" + publicKey + "');" +
                    "user.private_key = '" + privateKey + "';" +
                    "print(user.get_post_memo_signed_transaction('" + memoContent + "'))");
        } catch (IOException e) {
            throw new TransactionCreationException("Failed to create Memo transaction.", e);
        }
    }
}
