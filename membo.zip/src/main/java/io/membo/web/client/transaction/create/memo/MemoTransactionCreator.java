package io.membo.web.client.transaction.create.memo;

import io.membo.web.client.transaction.create.TransactionCreator;
import org.springframework.stereotype.Component;

@Component
public interface MemoTransactionCreator extends TransactionCreator {
}
