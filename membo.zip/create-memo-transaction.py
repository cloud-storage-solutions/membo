#!/usr/bin/python3
from bchmemo import MemoUser

user=MemoUser('<put_public_key_here>')
user.private_key = '<put_private_key_here>'

print(user.get_post_memo_signed_transaction("test"))

